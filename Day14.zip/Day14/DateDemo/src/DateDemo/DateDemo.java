package DateDemo;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;   //format purpose packeage "text"
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;

public class DateDemo {

	public static void main(String[] args) {
		
		
		
		
		LocalDate d = LocalDate.of(1997, Month.FEBRUARY, 9);  //Manual date
		System.out.println(d);
		
		LocalDate d1 = LocalDate.now();  //current Date
		System.out.println(d1);
		
		LocalTime t = LocalTime.now();  //current time
		System.out.println(t);
		
		LocalTime t1 = LocalTime.of(12,35,10,9999);   //Maual time
		System.out.println(t1);

		LocalTime tz = LocalTime.now(ZoneId.of("Indian/Kerguelen"));
		System.out.println(tz);
		
		for(String i : ZoneId.getAvailableZoneIds()) {     //get timeZone places
		System.out.println(i);
		}
		
		Instant I = Instant.now();
		System.out.println(I);
		
		LocalDateTime dt = LocalDateTime.now();  //Date and time both
		System.out.println(dt);
		
		SimpleDateFormat s1 = new SimpleDateFormat("dd/YYYY/MM HH:mm:ss");  
	    Date date1 = new Date();  
	    System.out.println(s1.format(date1));  
	    
	    Date date2=new Date();  
	    System.out.println(date2); 
	    
	    Date date3 = new Date();
	    // Display the Date & Time using toString()
	    System.out.println(date3.toString());
	    
	    System.out.println();	    
	    Date date4 = new Date();
	    System.out.println(date4.toString());
	    String dateFormat = "hh:mm:ss a dd-MMM-yyyy"; 
	    SimpleDateFormat s2 = new SimpleDateFormat(dateFormat); 
	    System.out.println(s2.format(date4)); 
	    
	    System.out.println();
		String dateFormat1 = "30/03/2021 08:22:15";
		Date date5 = null;
		try {
			date5 = new  SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(dateFormat1);
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
			System.out.println(date5);

		
	}

}
