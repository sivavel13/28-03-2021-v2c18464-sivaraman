package TypecastingDemo;

public class TypecastingDemo {

	public static void main(String[] args) {
		
			System.out.println("Convert Strings(letters) to Numeric(Numbers) - parse method");

		    String s = "8610";
		    
		    int i1=Integer.parseInt(s);  //String to int used
			System.out.println(i1);  
			
			float f1 = Float.parseFloat(s);   //String to Float used
			System.out.println(f1);
			
			double d1 = Double.parseDouble(s);   //String to Double used
			System.out.println(d1);
			
			   
			
			System.out.println("Convert Numeric(Numbers) to Strings(letters) - tostring method");
			
			int i = 500;
			String s2=Integer.toString(i);  // int to String used
			System.out.println(s2); 		// same like float, double 
			
			System.out.println("Converting (numeric to string) or (string to numeric) possible for (valueof) method");
			
			String s4 = "254";
			Integer i2=Integer.valueOf(s4);   //String to int object used(valueof)
			System.out.println(i2);
			
			Integer i3 = 345;
			String s3=String.valueOf(i3);   //int to String object used(valueof)
			System.out.println(s3); 
			
			System.out.println("Numbers to number no need any method");
			
			int ai = 100;    //Implicity or Widening Casting(autometic conversion)
			double di = ai;
			
			System.out.println(di);
			
			double id = 2000000000;   //EXplicity or Narrow Casting(Manual conversion)
			int ia = (int)id;
			System.out.println(id);
	}

}
